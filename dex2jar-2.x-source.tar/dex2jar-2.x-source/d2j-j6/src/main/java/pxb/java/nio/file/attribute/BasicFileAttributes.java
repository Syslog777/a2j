package pxb.java.nio.file.attribute;

public interface BasicFileAttributes {
}
