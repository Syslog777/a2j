package res;

public class ResParent {
    public void someMethod(int a, String b) {
    }

    public void bbb(int a, String b) {
    }
}
