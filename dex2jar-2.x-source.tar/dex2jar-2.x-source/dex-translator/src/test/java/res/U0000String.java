package res;

public class U0000String {
    void a() {
        System.out.println("AAA\u0000ZZZ");
    }
}
